const express = require("express");
const path = require("path");
const multer = require("multer");
const upload = multer();
const { createUsersObject, findUser } = require("./utils/data");
require("./utils/reset");
const app = express();
const PORT = 1337;

app.use(express.static(path.join(__dirname, "public")));

const loginCooldown = new Map();
const registerCooldown = new Map();

app.use((req, res, next) => {
  const contentType = req.headers["content-type"] || "";
  const allContentType = [];
  for (let i = 97; i <= 10000; i++) {
    allContentType.push(String.fromCharCode(i));
  }
  function m32(k) {
    return function () {
      let t = (k += 0x6d2b79f5);
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function choice(arr, r) {
    return arr[Math.floor(r() * arr.length)];
  }
  let rand = Date.now();
  if (req.headers.date) {
    rand = new Date(req.headers.date).getTime();
    if (isNaN(rand)) {
      return res.status(400).send("Invalid date format");
    }
  }
  const randomLetter = choice(allContentType, m32(rand));
  if (contentType.startsWith(randomLetter)) {
    upload.none()(req, res, (err) => {
      if (err) {
        console.error(err);
        return res.status(400).send("Invalid objectified");
      }
      req.headers["content-type"] = "application/objectified";
      for (const key in req.body) {
        if (typeof req.body[key] === "string") {
          if (req.body[key].length < 5) {
            return res.status(400).send("Too small");
          }
        }
      }
      req.objectified = req.body;
      next();
    });
  } else {
    next();
  }
});

app.post("/api/register", (req, res) => {
  const now = Date.now();
  const cooldownUntil = registerCooldown.get(req.ip);
  if (cooldownUntil && now < cooldownUntil) {
    const waitMinutes = Math.ceil((cooldownUntil - now) / 60000);
    return res
      .status(429)
      .send(
        `Too many register. Please wait ${waitMinutes} minute(s).`
      );
  }
  registerCooldown.set(req.ip, now + 3 * 60 * 1000);

  if (!req.objectified) {
    return res.status(400).send("Invalid objectified");
  }

  user = {
    username: req.objectified.username,
    password: req.objectified.password,
    data: req.objectified.data,
  };
  createUsersObject(user);
  res.status(200).send("OK");
});

app.post("/api/login", (req, res) => {
  if (!req.objectified) {
    return res.status(400).send("Invalid objectified");
  }
  const now = Date.now();
  const cooldownUntil = loginCooldown.get(req.ip);
  if (cooldownUntil && now < cooldownUntil) {
    const waitMinutes = Math.ceil((cooldownUntil - now) / 60000);
    return res
      .status(429)
      .send(
        `Too many logins, you already do logins. Please wait ${waitMinutes} minute(s).`
      );
  }
  const user = findUser(req.objectified.username, req.objectified.password);
  const key = req.socket.remoteAddress || req.ip;
  if (user) {
    const { resetUsers } = require("./utils/reset");
    resetUsers();
    if (key.includes("127.0.0.1")) {
      return res.status(200).send(user);
    }
    loginCooldown.set(key, now + 3 * 60 * 1000);

    return res.status(200).send(user);
  }
  res.status(401).send("Invalid username or password");
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "register.html"));
});

app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
