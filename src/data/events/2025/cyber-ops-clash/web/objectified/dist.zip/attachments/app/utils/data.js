const Objectified = require("./objectified");
const util = require("util");
const crypto = require("crypto");
const flag = process.env.FLAG || "flag{flag}";

function hiddenMessage(str, parts) {
  const chunks = splitHiddenMessage(str, parts);
  return chunks.map(encMsg);
}

function splitHiddenMessage(str, parts = 3, padChar = "_") {
  let len = str.length;
  const remainder = len % parts;

  if (remainder !== 0) {
    const padLength = parts - remainder;
    str = str + padChar.repeat(padLength);
    len = str.length;
  }

  const chunkSize = len / parts;
  const result = [];

  for (let i = 0; i < parts; i++) {
    result.push(str.slice(i * chunkSize, (i + 1) * chunkSize));
  }

  return result;
}

function encMsg(str) {
  return str.replace(/[a-zA-Z]/g, (c) =>
    String.fromCharCode(
      (c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26
    )
  );
}

const flagHidden = hiddenMessage(flag, 3);
console.log(`FLAG HIDDEN: ${JSON.stringify(flagHidden)}`);
console.log(`FLAG: ${flag}`);
const users = {
  users: [
    {
      username: "user1",
      password: crypto.randomBytes(16).toString("hex"),
      data: {
        custom: {
          message:
            "Widespread psychological suffering, boredom, anxiety, lack of fulfillment, severe environmental degradation, species extinction, pollution, overpopulation. What do all of these have in common? They stem from one source: the modern technological system. As the technological system progresses, human suffering and enslavement will inevitably increase and wild nature will be further destroyed. " +
            flagHidden[0] +
            "We hear again and again about the supposed “benefits” of modern technology, but this ignores that the “positives” are all vastly outweighed by the negatives and ultimately negated by its impending existential doom.",
          causeby: "Capitalism",
          actor: "Humanity",
          writtenBy: "Replican",
        },
        author: {
          name: "Replican",
        },
        friends: ["user2", "user3"],
        password: crypto.randomBytes(16).toString("hex"),
      },
    },
    {
      username: "user2",
      password: crypto.randomBytes(16).toString("hex"),
      data: {
        custom: {
          message:
            "Technology was once meant to liberate, but now it shackles. We've traded community for connectivity, depth for dopamine. Surveillance is sold as convenience, and efficiency " +
            flagHidden[1] +
            "has replaced empathy. The cost? A dehumanized society increasingly detached from meaning.",
          causeby: "Corporate Technocracy",
          actor: "Big Tech",
          writtenBy: "User Two",
        },
        author: {
          name: "User Two",
        },
        friends: ["user1", "user3"],
        password: crypto.randomBytes(16).toString("hex"),
      },
    },
    {
      username: "user3",
      password: "password3",
      data: {
        custom: {
          message:
            "The technological system is not neutral—it shapes our values, behaviors, and even our perception of reality. In optimizing " +
            flagHidden[2] +
            " life, we've lost life's essence. We automate away purpose, and digitize our existence into metrics, likes, and engagement. But what does it mean to truly live?",
          causeby: "Systemic Optimization",
          actor: "Post-industrial Society",
          writtenBy: "User Three",
        },
        author: {
          name: "User Three",
        },
        friends: ["user1", "user2"],
        password: "password3",
      },
    },
  ],
};

function findUser(username, password) {
  if (typeof username !== "string") {
    return;
  }
  if (typeof password !== "string") {
    return;
  }
  const allUsers = Objectify.get("users");
  for (const user of allUsers) {
    if (user.username === username && user.password === password) {
      if (
        user.data.password === password ||
        user.data.password.value === password
      ) {
        
        return user;
      }
    }
  }
  return null;
}

let Objectify = new Objectified(users);

function resetObjectify(newUsers) {
  Objectify = new Objectified(newUsers);
}

function customObjectFields(objStr) {
  try {
    if (typeof objStr !== "string") {
      throw new Error("Input must be a string");
    }

    const lines = objStr.trim().split(/\r?\n/);
    const result = {};

    for (let lineNum = 0; lineNum < lines.length; lineNum++) {
      const line = lines[lineNum].trim();
      if (!line) continue;

      const parts = line.split(/\s+/);
      let current = result;
      let expectingKey = true;

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (part.startsWith("##")) {
          const value = part.slice(2);
          if (value.length === 0) {
            console.warn(
              `Empty value after ## at line ${lineNum + 1}, part[${i}]`
            );
          }
          current.value = value;
          expectingKey = false;
        } else if (part.startsWith("#")) {
          const key = part.slice(1);
          if (key.length === 0) {
            throw new Error(`Empty key at line ${lineNum + 1}, part[${i}]`);
          }
          if (!expectingKey) {
            throw new Error(
              `Unexpected key '${key}' after a value at line ${
                lineNum + 1
              }, part[${i}]`
            );
          }
          current[key] = {};
          current = current[key];
        } else {
          throw new Error(
            `Invalid token '${part}' at line ${lineNum + 1}, part[${i}]`
          );
        }
      }
    }

    function unwrap(obj) {
      if (obj && typeof obj === "object") {
        if ("value" in obj && Object.keys(obj).length === 1) {
          return obj.value;
        }
        for (const k in obj) {
          obj[k] = unwrap(obj[k]);
        }
      }
      return obj;
    }

    return unwrap(result);
  } catch (err) {
    console.error("Error in customObjectFields:", err.message);
    return null;
  }
}

function createUsersObject(user) {
  if (typeof user.username !== "string") {
    return;
  }
  if (typeof user.password !== "string") {
    return;
  }
  if (typeof user.data !== "string") {
    return;
  }
  const userObj = JSON.parse(`
{
    "username": ${JSON.stringify(user.username)},
    "password": ${JSON.stringify(user.password)}
}
`);
  Objectify.get("users").push(userObj);
  const initCustomObject = customObjectFields(user.data);
  allUsers = Objectify.get("users");
  for (const user of allUsers) {
    if (user.username === userObj.username) {
      userObj["data"] = initCustomObject;
      userObj["data"]["password"] = userObj.password;
    }
  }
  Objectify.push("users", userObj);
  Objectify.removeDuplicateUsers();
  allUsersAgain = Objectify.get("users");

  const usersArr = [];
  for (const user of allUsersAgain) {
    if (user["data"]["custom"]) {
      if (user["data"]["author"]["name"]) {
        user["data"]["custom"]["writtenBy"] = user["data"]["author"]["name"];
      }
      if (user["data"]["friends"]) {
        const friends = user["data"]["friends"];
        for (i = 0; i < friends.length; i++) {
          if (!friends[i]) {
            friends[i] = usersArr[i];
          }
        }
      }
      if (user["data"]["hiddenMessage"]) {
        const hiddenMsg = user["data"]["hiddenMessage"];
        user["data"]["hiddenMessage"] = encMsg(hiddenMsg);
      }
    }

    user["data"][user.username] = crypto.randomBytes(16).toString("hex");
    user["data"]["password"] = crypto.randomBytes(16).toString("hex");

    if (user["data"]["delete"]) {
      delete user["data"][user["data"]["delete"]];
    }

    usersArr.push(user);
  }
  return userObj;
}

module.exports = { createUsersObject, findUser, Objectify, resetObjectify, users, flagHidden };
