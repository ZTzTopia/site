const util = require("util");
const crypto = require("crypto");
const { resetObjectify,flagHidden } = require("./data");

function resetUsers() {
const initialUsers = {
  users: [
    {
      username: "user1",
      password: crypto.randomBytes(16).toString("hex"),
      data: {
        custom: {
          message:
            "Widespread psychological suffering, boredom, anxiety, lack of fulfillment, severe environmental degradation, species extinction, pollution, overpopulation. What do all of these have in common? They stem from one source: the modern technological system. As the technological system progresses, human suffering and enslavement will inevitably increase and wild nature will be further destroyed. " +
            flagHidden[0] +
            "We hear again and again about the supposed “benefits” of modern technology, but this ignores that the “positives” are all vastly outweighed by the negatives and ultimately negated by its impending existential doom.",
          causeby: "Capitalism",
          actor: "Humanity",
          writtenBy: "Replican",
        },
        author: {
          name: "Replican",
        },
        friends: ["user2", "user3"],
        password: crypto.randomBytes(16).toString("hex"),
      },
    },
    {
      username: "user2",
      password: crypto.randomBytes(16).toString("hex"),
      data: {
        custom: {
          message:
            "Technology was once meant to liberate, but now it shackles. We've traded community for connectivity, depth for dopamine. Surveillance is sold as convenience, and efficiency " +
            flagHidden[1] +
            "has replaced empathy. The cost? A dehumanized society increasingly detached from meaning.",
          causeby: "Corporate Technocracy",
          actor: "Big Tech",
          writtenBy: "User Two",
        },
        author: {
          name: "User Two",
        },
        friends: ["user1", "user3"],
        password: crypto.randomBytes(16).toString("hex"),
      },
    },
    {
      username: "user3",
      password: "password3",
      data: {
        custom: {
          message:
            "The technological system is not neutral—it shapes our values, behaviors, and even our perception of reality. In optimizing " +
            flagHidden[2] +
            " life, we've lost life's essence. We automate away purpose, and digitize our existence into metrics, likes, and engagement. But what does it mean to truly live?",
          causeby: "Systemic Optimization",
          actor: "Post-industrial Society",
          writtenBy: "User Three",
        },
        author: {
          name: "User Three",
        },
        friends: ["user1", "user2"],
        password: "password3",
      },
    },
  ],
};
  resetObjectify(initialUsers);
    console.log(`[${util.format(new Date())}][Scheduler] Users have been reset.`);
}

setInterval(resetUsers, 10000);

// resetUsers();

module.exports = { resetUsers };
