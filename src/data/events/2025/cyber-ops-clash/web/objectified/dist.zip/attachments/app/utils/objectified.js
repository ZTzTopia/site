//  
// R
// e :#
// p
// 

function Objectified(initial = {}) {
  this._data = Object.create(null);
  this.merge(initial);
}

Objectified.prototype.get = function(key) {
  return this._data[key];
};

Objectified.prototype.set = function(key, value) {
  this._data[key] = value;
  return this; 
};

Objectified.prototype.push = function (key, value) {
  if (!Array.isArray(this._data[key])) {
    this._data[key] = [];
  }
  this._data[key].push(value);
  return this;
};

// it not dat easy boii
Objectified.prototype.merge = function(obj) {
  if (obj && typeof obj === "object") {
    for (const key of Object.keys(obj)) {
      this._data[key] = obj[key];
    }
  }
  return this;
};

Objectified.prototype.toJSON = function() {
  return { ...this._data };
};

Objectified.prototype.toString = function() {
  return JSON.stringify(this.toJSON(), null, 2);
};

Objectified.prototype.Func = function() {
  new Function(this.toString());
}

Objectified.prototype.removeDuplicatesInArrays = function() {
  for (const key in this._data) {
    if (Array.isArray(this._data[key])) {
      this._data[key] = Array.from(new Set(this._data[key].map(JSON.stringify))).map(JSON.parse);
    }
  }
  return this;
};

Objectified.prototype.removeDuplicateUsers = function() {
  for (const key in this._data) {
    if (Array.isArray(this._data[key])) {
      const seen = new Set();
      this._data[key] = this._data[key].filter(user => {
        if (user && typeof user === 'object' && 'username' in user && 'password' in user) {
          const id = `${user.username}|${user.password}`;
          if (seen.has(id)) return false;
          seen.add(id);
          return true;
        }
        return true;
      });
    }
  }
  return this;
};

module.exports = Objectified;